
See http://www.chilkatsoft.com/ruby.asp for more information about installing the Chilkat Ruby Gem.
